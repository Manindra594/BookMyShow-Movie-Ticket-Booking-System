package com.acciojob.book_my_show.Services;

import com.acciojob.book_my_show.Dtos.Userdto;
import com.acciojob.book_my_show.Enums.Usertype;
import com.acciojob.book_my_show.Repository.Userrepository;
import com.acciojob.book_my_show.Transformer.Applicationtransformer;
import com.acciojob.book_my_show.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

@Service
public class Userservice {
    private Applicationtransformer transformer;
    private Userrepository userrepository;
    @Autowired
    public Userservice(Applicationtransformer transformer,Userrepository userrepository){
        this.transformer = transformer;
        this.userrepository = userrepository;
    }
    public User registercustomer(Userdto userdto){
        User user = transformer.transformuserdtotouser(userdto, Usertype.CUSTOMER.toString());
        userrepository.save(user);
        return user;
    }
    public  User registerTheaterowner(Userdto userdto){
       User user =  transformer.transformuserdtotouser(userdto,Usertype.THEATER_OWNER.toString());
       userrepository.save(user);
       return user;
    }
}
